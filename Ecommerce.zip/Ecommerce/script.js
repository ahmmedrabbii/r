var Menuitems = document.getElementById("Menuitems");
Menuitems.style.maxHeight="0px";
